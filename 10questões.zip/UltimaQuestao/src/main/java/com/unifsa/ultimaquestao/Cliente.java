package com.unifsa.ultimaquestao;

public class Cliente {
    String nome;
    String tipo;

    public Cliente(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    public String getTipo() { return tipo; }
    public String getNome() { return nome; }
}
