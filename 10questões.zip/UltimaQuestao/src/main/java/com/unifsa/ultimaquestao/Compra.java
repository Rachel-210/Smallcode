package com.unifsa.ultimaquestao;

public class Compra {
    double valorBruto;
    double totalDescontos;

    public Compra(double valor) {
        this.valorBruto = valor;
        this.totalDescontos = 0;
    }

    public void aplicarDesconto(double valor) {
        this.totalDescontos += valor;
    }

    public double getValorFinal() {
        return valorBruto - totalDescontos;
    }

    public double getValorBruto() { return valorBruto; }
    public double getTotalDescontos() { return totalDescontos; }
}
