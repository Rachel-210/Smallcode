package com.unifsa.ultimaquestao;

public class ProcessadorVendas {
    public void finalizarCompra(Compra compra, Cliente cliente, Cupom cupom) {
        double valorOriginal = compra.getValorBruto();

        if (cliente.getTipo().equalsIgnoreCase("VIP")) {
            double descontoVip = compra.getValorFinal() * 0.05;
            compra.aplicarDesconto(descontoVip);
        }

        if (cupom.getCodigo().equals("CONSUMIDOR44")) {
            if (cupom.validarEAplicar()) {
                compra.aplicarDesconto(cupom.getValorDesconto());
            } else {
                System.out.println("(Aviso) Cupom " + cupom.getCodigo() + " expirado ou sem usos!");
            }
        }

        exibirExtrato(compra);
    }
    
    private void exibirExtrato(Compra c) {
        System.out.println("\n--- EXTRATO DE VENDA ---");
        System.out.println("Valor Original: R$ " + c.getValorBruto());
        System.out.println("Desconto Aplicado: R$ " + c.getTotalDescontos());
        System.out.println("Valor Final: R$ " + c.getValorFinal());
        System.out.println("------------------------");
    }
}
