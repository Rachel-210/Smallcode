package com.unifsa.ultimaquestao;

public class MainVenda {

    public static void main(String[] args) {
        Cliente clienteVip = new Cliente("Augusto", "VIP");
        Cupom cupomPromocional = new Cupom("CONSUMIDOR20", 20.00, 1);
        ProcessadorVendas processador = new ProcessadorVendas();

        // Primeira Compra: R$ 100,00
        System.out.println("Iniciando Primeira Compra...");
        Compra compra1 = new Compra(100.00);
        processador.finalizarCompra(compra1, clienteVip, cupomPromocional);

        // Segunda Compra: Mesmos objetos (simulando reuso do cupom)
        System.out.println("\nTentando Segunda Compra com o mesmo cupom...");
        Compra compra2 = new Compra(100.00);
        processador.finalizarCompra(compra2, clienteVip, cupomPromocional);
    }
}
