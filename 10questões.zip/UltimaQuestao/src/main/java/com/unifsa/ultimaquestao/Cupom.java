package com.unifsa.ultimaquestao;

public class Cupom {
    private String codigo;
    private double valorDesconto;
    private int usosRestantes;

    public Cupom(String codigo, double valorDesconto, int usos) {
        this.codigo = codigo;
        this.valorDesconto = valorDesconto;
        this.usosRestantes = usos;
    }

    public boolean validarEAplicar() {
        if (usosRestantes > 0) {
            usosRestantes--;
            return true;
        }
        return false;
    }

    public double getValorDesconto() { return valorDesconto; }
    public String getCodigo() { return codigo; }
}
