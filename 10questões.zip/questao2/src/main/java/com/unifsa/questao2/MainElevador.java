package com.unifsa.questao2;

public class MainElevador {

    public static void main(String[] args) {
        ClasseElevador elevador = new ClasseElevador(3);
        
        System.out.println("--- Simulando subida alem do limite ---");
        elevador.subir(); 
        elevador.subir(); 
        elevador.subir(); 
        elevador.subir(); 

        System.out.println("\n--- Simulando descida alem do limite ---");
        elevador.descer(); 
        elevador.descer(); 
        elevador.descer(); 
        elevador.descer(); 
    }
}
