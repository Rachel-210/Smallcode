package com.unifsa.questao2;

public class ClasseElevador {
    int andarAtual;
    int totalAndares;
    
    public ClasseElevador(int totalAndares) {
        this.andarAtual = 0;
        this.totalAndares = totalAndares;
    }
    
    public void subir() {
        if (andarAtual < totalAndares) {
            andarAtual++;
            System.out.println("Subindo... Andar atual: " + andarAtual);
        } else {
            System.out.println("ERRO! O elevador ja esta no ultimo andar ("+totalAndares+").");
        }
        }
    public void descer() {
        if (andarAtual > 0){
            andarAtual--;
            System.out.println("Descendo... Andar atual: " + andarAtual);
        } else {
            System.out.println("ERRO! O elevador ja esta no terreo(0).");
        }
     }
}
