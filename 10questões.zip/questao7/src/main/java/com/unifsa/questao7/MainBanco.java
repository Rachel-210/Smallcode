package com.unifsa.questao7;

public class MainBanco {

    public static void main(String[] args) {
        ClasseBanco contaBancaria = new ClasseBanco();
        double valorSaque = 1500.00;

        System.out.println("Saldo atual: R$ " + contaBancaria.getSaldo());
        System.out.println("Tentando sacar: R$ " + valorSaque);

        if (contaBancaria.sacar(valorSaque)) {
            System.out.println("Saque realizado com sucesso!");
        } else {
            System.err.println("Erro: Saldo insuficiente.");
        }

        System.out.println("Saldo final: R$ " + contaBancaria.getSaldo());
    }
}
