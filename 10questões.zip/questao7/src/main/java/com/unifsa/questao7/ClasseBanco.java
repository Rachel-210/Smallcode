package com.unifsa.questao7;

public class ClasseBanco {
    double saldo = 1000.00; 

    public boolean sacar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
            return true; 
        }
        return false; 
    }

    public double getSaldo() {
        return saldo;
    }
}

