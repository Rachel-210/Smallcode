package com.unifsa.questao6;

public class ClasseGuerreiro {
    int vida = 100;
    int escudo = 50;
    
    public void receberDano(int pontos) {
        if (pontos <= escudo) {
            escudo -= pontos;
        } else {
            int danoRestante = pontos - escudo;
            escudo = 0;
            vida -= danoRestante;
            
            if (vida < 0) vida = 0;
        }
    }

    public void exibirStatus() {
        System.out.println("Escudo: " + escudo);
        System.out.println("Vida: " + vida);
    }
}
