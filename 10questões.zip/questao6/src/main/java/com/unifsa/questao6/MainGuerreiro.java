package com.unifsa.questao6;

public class MainGuerreiro {

    public static void main(String[] args) {
       ClasseGuerreiro guerreiro = new ClasseGuerreiro();
        
        System.out.println("--- Combate ---");
        guerreiro.exibirStatus();
        
        System.out.println("Recebendo 80 de dano...");
        guerreiro.receberDano(80);
        
        guerreiro.exibirStatus();
    }
}
