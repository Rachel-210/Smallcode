package com.unifsa.questao3;

public class ClassePet {
    String nome;
    int fome;
    
    public ClassePet(String nome, int fomeInicial) {
        this.nome = nome;
        
        if (fomeInicial > 100) {
           this.fome = 100;
        } else if (fomeInicial < 0){
            this.fome = 0;
        } else {
            this.fome = fomeInicial;
        }
    }
    
    public void alimentar() {
        System.out.println("Alimentando " + this.nome + "...");
        this.fome -= 10;
        
        if (this.fome < 0) {
            this.fome = 0;
        }
         System.out.println ("Nivel de fome atual: " + this.fome);
    }
    
}
