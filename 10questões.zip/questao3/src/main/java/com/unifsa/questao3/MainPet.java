package com.unifsa.questao3;

public class MainPet {

    public static void main(String[] args) {
       ClassePet pet = new ClassePet("Dino", 5);
        
        System.out.println("Estado inicial: Fome = " + 5);
        pet.alimentar();
    }
}
