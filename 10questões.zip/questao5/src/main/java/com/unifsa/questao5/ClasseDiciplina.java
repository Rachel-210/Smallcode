package com.unifsa.questao5;

public class ClasseDiciplina {
    double notaFinal;
    int presenca;
    
    public ClasseDiciplina(double nota, int presenca ) {
        this.notaFinal = nota;
        this.presenca = presenca;   
    }
    
    public boolean verificarAprovacao() {
        if (this.notaFinal >= 7.0 && this.presenca >= 75){
            return true;
        } else {
            return false;
        }
    }
    
    public void finalRelatorio() {
        System.out.println("Nota: " + this.notaFinal);
        System.out.println("Presenca: " + this.presenca + "%");
        
        if (verificarAprovacao()){
            System.out.println("Aprovado");
        }else {
            System.out.println("Reprovado");
        }
        
        if (this.notaFinal < 7.0) {
           System.out.println("Reprovado por Nota"); 
        }
      
        if (this.presenca < 75) {
            System.out.println("Reprovado por Presenca");
        }
    }
}
