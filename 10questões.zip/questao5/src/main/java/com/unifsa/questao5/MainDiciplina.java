package com.unifsa.questao5;

public class MainDiciplina {

    public static void main(String[] args) {
       ClasseDiciplina diciplina = new ClasseDiciplina(9.0, 70);
       
       System.out.println("----Resultado da analise do sistema-----");
       diciplina.finalRelatorio();
    }
}
