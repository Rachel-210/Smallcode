package com.unifsa.questao8;

public class MainSensor {

    public static void main(String[] args) {
        Semaforo semaforoNorte = new Semaforo();
        Veiculo ambulancia01 = new Veiculo("ABC-1234", "Ambulância");
        Via avenidaCentral = new Via("Avenida Central", 500);
        SensorPassagem sensor01 = new SensorPassagem(101);
        ControladorCentral cerebro = new ControladorCentral();

        sensor01.estaAtivado = true;

        cerebro.processarPrioridade(ambulancia01, avenidaCentral, semaforoNorte, sensor01);
    }
}
