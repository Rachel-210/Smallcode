package com.unifsa.questao8;

public class Veiculo {
    String placa;
    String tipo;

    Veiculo(String placa, String tipo) {
        this.placa = placa;
        this.tipo = tipo;
    }
}
