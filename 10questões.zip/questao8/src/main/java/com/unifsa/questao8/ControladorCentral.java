package com.unifsa.questao8;

public class ControladorCentral {
    public void processarPrioridade(Veiculo v, Via via, Semaforo s, SensorPassagem sensor) {
        if (sensor.estaAtivado && v.tipo.equalsIgnoreCase("Ambulância")) {
            if (s.cor.equals("Vermelho")) {
                s.trocar();
                System.out.println("--- Relatorio ---");
                System.out.println("Prioridade detectada para [" + v.placa + "] na " + via.nome + ".");
                System.out.println("Sinal alterado para " + s.cor + ".");
            }
        }
    }
}
