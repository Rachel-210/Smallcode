package com.unifsa.questao8;

public class Semaforo {
   String cor = "Vermelho";

    public void trocar() {
        if (cor.equals("Vermelho")) {
            cor = "Verde";
        } else {
            cor = "Vermelho";
        }
    }
}
