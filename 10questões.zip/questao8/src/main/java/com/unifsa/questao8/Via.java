package com.unifsa.questao8;

public class Via {
    String nome;
    int fluxoVeiculos;

    Via(String nome, int fluxoVeiculos) {
        this.nome = nome;
        this.fluxoVeiculos = fluxoVeiculos;
    }
}
