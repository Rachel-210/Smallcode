package com.unifsa.questao8;

public class SensorPassagem {
    int id;
    boolean estaAtivado = false;

    SensorPassagem(int id) {
        this.id = id;
    }
}
