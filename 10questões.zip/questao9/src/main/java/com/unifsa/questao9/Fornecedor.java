package com.unifsa.questao9;

public class Fornecedor {
    String nomeEmpresa;
    int tempoEntregaDias;

    Fornecedor(String nome, int dias) {
        this.nomeEmpresa = nome;
        this.tempoEntregaDias = dias;
    }

    public void enviarProdutos(int qtd) {
    }
}
