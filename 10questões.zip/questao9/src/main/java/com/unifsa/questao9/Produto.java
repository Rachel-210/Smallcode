package com.unifsa.questao9;

public class Produto {
    String nome;
    double precoUnitario;
    int pontoCritico;

    Produto(String nome, double preco, int pontoCritico) {
        this.nome = nome;
        this.precoUnitario = preco;
        this.pontoCritico = pontoCritico;
    }
}
