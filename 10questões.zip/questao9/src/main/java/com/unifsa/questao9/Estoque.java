package com.unifsa.questao9;

public class Estoque {
    int quantidadeAtual;
    String localizacaoCorredor;

    Estoque(int inicial, String local) {
        this.quantidadeAtual = inicial;
        this.localizacaoCorredor = local;
    }

    public void reduzirEstoque(int qtd) {
        this.quantidadeAtual -= qtd;
    }

    public void adicionarEstoque(int qtd) {
        this.quantidadeAtual += qtd;
    }
}
