package com.unifsa.questao9;

public class PedidoCompra {
    int idPedido;
    String status;

    PedidoCompra(int id, String status) {
        this.idPedido = id;
        this.status = status;
    }
}
