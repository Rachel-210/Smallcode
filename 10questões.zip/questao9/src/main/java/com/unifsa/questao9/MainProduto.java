package com.unifsa.questao9;

public class MainProduto {

    public static void main(String[] args) {
       Produto p1 = new Produto("Computadores", 1200.00, 10);
        Estoque e1 = new Estoque(15, "Corredor 3");
        Fornecedor f1 = new Fornecedor("Forn intel", 3);
        GerenteLogistico gerente = new GerenteLogistico();

        gerente.processarVenda(7, p1, e1, f1); 
    }
}
