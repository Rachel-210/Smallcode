package com.unifsa.questao9;

public class GerenteLogistico {
   public void processarVenda(int qtdVendida, Produto p, Estoque e, Fornecedor f) {
        System.out.println("Processando venda de " + qtdVendida + " unidades de " + p.nome + "...");
        e.reduzirEstoque(qtdVendida);
        
        System.out.println("Estoque atual: " + e.quantidadeAtual);

        if (e.quantidadeAtual <= p.pontoCritico) {
            System.out.println("Estoque Critico detectado para (" + p.nome + ").");
            
            PedidoCompra novoPedido = new PedidoCompra(1001, "Pendente");
            
            f.enviarProdutos(50);
            
            novoPedido.status = "Enviado";
            
            System.out.println("Gerando Pedido de Compra com o fornecedor (" + f.nomeEmpresa + "). Status: " + novoPedido.status);
        }
    } 
}
