package com.unifsa.questao1;

public class MainVideo {

    public static void main(String[] args) {
       ClasseVideo v1 = new ClasseVideo();
        v1.titulo = "Aula de POO";
        v1.duracao = 3;

       ClasseVideo v2 = new ClasseVideo();
        v2.titulo = "Aula de Modelagem";
        v2.duracao = 2; 
        
        
        v1.alternarPlay();
        

        System.out.println("Video 1 - Titulo: " + v1.titulo + " Duracao: " + v1.duracao + " minutos | Play: " + v1.estaDandoPlay);

        System.out.println("Video 2 - Titulo: " + v2.titulo + " Duracao: " + v2.duracao + " minutos | Play: " + v2.estaDandoPlay);

    }
}
