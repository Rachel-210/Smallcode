package com.unifsa.questao1;

public class ClasseVideo {
    String titulo;
    int duracao;
    boolean estaDandoPlay = false;  

    void titulo() {
        System.out.println(titulo);
    }

    void duracao() {
        System.out.println(duracao);
    }

    public void alternarPlay() {
        estaDandoPlay = !estaDandoPlay;
    }
}
